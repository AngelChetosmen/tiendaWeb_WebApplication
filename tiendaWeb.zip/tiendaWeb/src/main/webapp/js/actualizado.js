/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */



Swal.fire(
        {
            title: 'Actualizado correctamente.',
            icon: 'success',
            allowOutsideClick: false,
            allowEscapeKey: false,
            allowEnterKey: false,
            stopKeydownPropagation: false,
            confirmButtonText:
                    '<a href="ListaProductos" style="text-decoration:none; color:white;" >Lista de productos</a>',
            confirmButtonAriaLabel: 'Thumbs up, great!',
            
        }
); 